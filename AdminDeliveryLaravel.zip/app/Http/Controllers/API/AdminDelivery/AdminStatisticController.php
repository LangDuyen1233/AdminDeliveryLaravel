<?php


namespace App\Http\Controllers\API\AdminDelivery;


use App\Http\Controllers\Controller;

class AdminStatisticController extends Controller
{


}
